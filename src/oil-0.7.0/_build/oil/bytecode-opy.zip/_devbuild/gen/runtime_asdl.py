from _devbuild.gen.id_kind_asdl import Id_t
from _devbuild.gen.id_kind_asdl import Id_str

from asdl import pybase
from typing import Optional, List, Tuple, Dict, Any, cast

from asdl import runtime  # For runtime.NO_SPID
from asdl.runtime import NewRecord, NewLeaf
from _devbuild.gen.hnode_asdl import color_e, hnode, hnode_e, hnode_t, field

class builtin_t(pybase.SimpleObj):
  pass

class builtin_e(object):
  NONE = builtin_t(1)
  READ = builtin_t(2)
  ECHO = builtin_t(3)
  PRINTF = builtin_t(4)
  SHIFT = builtin_t(5)
  CD = builtin_t(6)
  PWD = builtin_t(7)
  PUSHD = builtin_t(8)
  POPD = builtin_t(9)
  DIRS = builtin_t(10)
  EXPORT = builtin_t(11)
  READONLY = builtin_t(12)
  LOCAL = builtin_t(13)
  DECLARE = builtin_t(14)
  TYPESET = builtin_t(15)
  UNSET = builtin_t(16)
  SET = builtin_t(17)
  SHOPT = builtin_t(18)
  TRAP = builtin_t(19)
  UMASK = builtin_t(20)
  SOURCE = builtin_t(21)
  DOT = builtin_t(22)
  EVAL = builtin_t(23)
  EXEC = builtin_t(24)
  WAIT = builtin_t(25)
  JOBS = builtin_t(26)
  FG = builtin_t(27)
  BG = builtin_t(28)
  COMPLETE = builtin_t(29)
  COMPGEN = builtin_t(30)
  COMPOPT = builtin_t(31)
  COMPADJUST = builtin_t(32)
  TRUE = builtin_t(33)
  FALSE = builtin_t(34)
  COLON = builtin_t(35)
  TEST = builtin_t(36)
  BRACKET = builtin_t(37)
  GETOPTS = builtin_t(38)
  COMMAND = builtin_t(39)
  TYPE = builtin_t(40)
  HASH = builtin_t(41)
  HELP = builtin_t(42)
  HISTORY = builtin_t(43)
  BUILTIN = builtin_t(44)
  ALIAS = builtin_t(45)
  UNALIAS = builtin_t(46)
  PUSH = builtin_t(47)
  APPEND = builtin_t(48)
  WRITE = builtin_t(49)
  GETLINE = builtin_t(50)
  JSON = builtin_t(51)
  REPR = builtin_t(52)
  USE = builtin_t(53)
  OPTS = builtin_t(54)
  ENV = builtin_t(55)
  FORK = builtin_t(56)

_builtin_str = {
  1: 'builtin.NONE',
  2: 'builtin.READ',
  3: 'builtin.ECHO',
  4: 'builtin.PRINTF',
  5: 'builtin.SHIFT',
  6: 'builtin.CD',
  7: 'builtin.PWD',
  8: 'builtin.PUSHD',
  9: 'builtin.POPD',
  10: 'builtin.DIRS',
  11: 'builtin.EXPORT',
  12: 'builtin.READONLY',
  13: 'builtin.LOCAL',
  14: 'builtin.DECLARE',
  15: 'builtin.TYPESET',
  16: 'builtin.UNSET',
  17: 'builtin.SET',
  18: 'builtin.SHOPT',
  19: 'builtin.TRAP',
  20: 'builtin.UMASK',
  21: 'builtin.SOURCE',
  22: 'builtin.DOT',
  23: 'builtin.EVAL',
  24: 'builtin.EXEC',
  25: 'builtin.WAIT',
  26: 'builtin.JOBS',
  27: 'builtin.FG',
  28: 'builtin.BG',
  29: 'builtin.COMPLETE',
  30: 'builtin.COMPGEN',
  31: 'builtin.COMPOPT',
  32: 'builtin.COMPADJUST',
  33: 'builtin.TRUE',
  34: 'builtin.FALSE',
  35: 'builtin.COLON',
  36: 'builtin.TEST',
  37: 'builtin.BRACKET',
  38: 'builtin.GETOPTS',
  39: 'builtin.COMMAND',
  40: 'builtin.TYPE',
  41: 'builtin.HASH',
  42: 'builtin.HELP',
  43: 'builtin.HISTORY',
  44: 'builtin.BUILTIN',
  45: 'builtin.ALIAS',
  46: 'builtin.UNALIAS',
  47: 'builtin.PUSH',
  48: 'builtin.APPEND',
  49: 'builtin.WRITE',
  50: 'builtin.GETLINE',
  51: 'builtin.JSON',
  52: 'builtin.REPR',
  53: 'builtin.USE',
  54: 'builtin.OPTS',
  55: 'builtin.ENV',
  56: 'builtin.FORK',
}

def builtin_str(val):
  # type: (builtin_t) -> str
  return _builtin_str[val]

class cmd_value_e(object):
  Argv = 1
  Assign = 2

_cmd_value_str = {
  1: 'cmd_value.Argv',
  2: 'cmd_value.Assign',
}

def cmd_value_str(tag):
  # type: (int) -> str
  return _cmd_value_str[tag]

class cmd_value_t(pybase.CompoundObj):
  def tag_(self):
    # type: () -> int
    return self.tag
  pass

class cmd_value__Argv(cmd_value_t):
  tag = 1
  __slots__ = ('argv', 'arg_spids', 'block')

  def __init__(self, argv=None, arg_spids=None, block=None):
    # type: (Optional[List[str]], Optional[List[int]], Optional[Any]) -> None
    self.argv = argv or []
    self.arg_spids = arg_spids or []
    self.block = block or None
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('cmd_value.Argv')
    L = out_node.fields

    if self.argv:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.argv:
        x0.children.append(NewLeaf(i0, color_e.StringConst))
      L.append(field('argv', x0))

    if self.arg_spids:  # ArrayType
      x1 = hnode.Array([])
      for i1 in self.arg_spids:
        x1.children.append(hnode.Leaf(str(i1), color_e.OtherConst))
      L.append(field('arg_spids', x1))

    if self.block is not None:  # MaybeType
      x2 = hnode.External(self.block)
      L.append(field('block', x2))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('cmd_value.Argv')
    L = out_node.fields
    if self.argv:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.argv:
        x0.children.append(NewLeaf(i0, color_e.StringConst))
      L.append(field('argv', x0))

    if self.arg_spids:  # ArrayType
      x1 = hnode.Array([])
      for i1 in self.arg_spids:
        x1.children.append(hnode.Leaf(str(i1), color_e.OtherConst))
      L.append(field('arg_spids', x1))

    if self.block is not None:  # MaybeType
      x2 = hnode.External(self.block)
      L.append(field('block', x2))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class cmd_value__Assign(cmd_value_t):
  tag = 2
  __slots__ = ('builtin_id', 'argv', 'arg_spids', 'pairs')

  def __init__(self, builtin_id=None, argv=None, arg_spids=None, pairs=None):
    # type: (Optional[builtin_t], Optional[List[str]], Optional[List[int]], Optional[List[assign_arg]]) -> None
    self.builtin_id = builtin_id
    self.argv = argv or []
    self.arg_spids = arg_spids or []
    self.pairs = pairs or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('cmd_value.Assign')
    L = out_node.fields

    assert self.builtin_id is not None
    x0 = hnode.Leaf(builtin_str(self.builtin_id), color_e.TypeName)
    L.append(field('builtin_id', x0))

    if self.argv:  # ArrayType
      x1 = hnode.Array([])
      for i1 in self.argv:
        x1.children.append(NewLeaf(i1, color_e.StringConst))
      L.append(field('argv', x1))

    if self.arg_spids:  # ArrayType
      x2 = hnode.Array([])
      for i2 in self.arg_spids:
        x2.children.append(hnode.Leaf(str(i2), color_e.OtherConst))
      L.append(field('arg_spids', x2))

    if self.pairs:  # ArrayType
      x3 = hnode.Array([])
      for i3 in self.pairs:
        x3.children.append(i3.PrettyTree())
      L.append(field('pairs', x3))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('cmd_value.Assign')
    L = out_node.fields
    assert self.builtin_id is not None
    x0 = hnode.Leaf(builtin_str(self.builtin_id), color_e.TypeName)
    L.append(field('builtin_id', x0))

    if self.argv:  # ArrayType
      x1 = hnode.Array([])
      for i1 in self.argv:
        x1.children.append(NewLeaf(i1, color_e.StringConst))
      L.append(field('argv', x1))

    if self.arg_spids:  # ArrayType
      x2 = hnode.Array([])
      for i2 in self.arg_spids:
        x2.children.append(hnode.Leaf(str(i2), color_e.OtherConst))
      L.append(field('arg_spids', x2))

    if self.pairs:  # ArrayType
      x3 = hnode.Array([])
      for i3 in self.pairs:
        x3.children.append(i3.AbbreviatedTree())
      L.append(field('pairs', x3))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class cmd_value(object):
  Argv = cmd_value__Argv
  Assign = cmd_value__Assign

class part_value_e(object):
  String = 1
  Array = 2

_part_value_str = {
  1: 'part_value.String',
  2: 'part_value.Array',
}

def part_value_str(tag):
  # type: (int) -> str
  return _part_value_str[tag]

class part_value_t(pybase.CompoundObj):
  def tag_(self):
    # type: () -> int
    return self.tag
  pass

class part_value__String(part_value_t):
  tag = 1
  __slots__ = ('s', 'quoted', 'do_split')

  def __init__(self, s=None, quoted=None, do_split=None):
    # type: (Optional[str], Optional[bool], Optional[bool]) -> None
    self.s = s
    self.quoted = quoted
    self.do_split = do_split
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('part_value.String')
    L = out_node.fields

    x0 = NewLeaf(self.s, color_e.StringConst)
    L.append(field('s', x0))

    x1 = hnode.Leaf('T' if self.quoted else 'F', color_e.OtherConst)
    L.append(field('quoted', x1))

    x2 = hnode.Leaf('T' if self.do_split else 'F', color_e.OtherConst)
    L.append(field('do_split', x2))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('part_value.String')
    L = out_node.fields
    x0 = NewLeaf(self.s, color_e.StringConst)
    L.append(field('s', x0))

    x1 = hnode.Leaf('T' if self.quoted else 'F', color_e.OtherConst)
    L.append(field('quoted', x1))

    x2 = hnode.Leaf('T' if self.do_split else 'F', color_e.OtherConst)
    L.append(field('do_split', x2))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class part_value__Array(part_value_t):
  tag = 2
  __slots__ = ('strs',)

  def __init__(self, strs=None):
    # type: (Optional[List[str]]) -> None
    self.strs = strs or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('part_value.Array')
    L = out_node.fields

    if self.strs:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.strs:
        x0.children.append(NewLeaf(i0, color_e.StringConst))
      L.append(field('strs', x0))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('part_value.Array')
    L = out_node.fields
    if self.strs:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.strs:
        x0.children.append(NewLeaf(i0, color_e.StringConst))
      L.append(field('strs', x0))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class part_value(object):
  String = part_value__String
  Array = part_value__Array

class value_e(object):
  Undef = 1
  Str = 2
  MaybeStrArray = 3
  AssocArray = 4
  Obj = 5

_value_str = {
  1: 'value.Undef',
  2: 'value.Str',
  3: 'value.MaybeStrArray',
  4: 'value.AssocArray',
  5: 'value.Obj',
}

def value_str(tag):
  # type: (int) -> str
  return _value_str[tag]

class value_t(pybase.CompoundObj):
  def tag_(self):
    # type: () -> int
    return self.tag
  pass

class value__Undef(value_t):
  tag = 1
  __slots__ = ()

  def __init__(self, ):
    # type: () -> None
    pass
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.Undef')
    L = out_node.fields

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.Undef')
    L = out_node.fields
    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class value__Str(value_t):
  tag = 2
  __slots__ = ('s',)

  def __init__(self, s=None):
    # type: (Optional[str]) -> None
    self.s = s
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.Str')
    L = out_node.fields

    x0 = NewLeaf(self.s, color_e.StringConst)
    L.append(field('s', x0))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.Str')
    L = out_node.fields
    x0 = NewLeaf(self.s, color_e.StringConst)
    L.append(field('s', x0))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class value__MaybeStrArray(value_t):
  tag = 3
  __slots__ = ('strs',)

  def __init__(self, strs=None):
    # type: (Optional[List[str]]) -> None
    self.strs = strs or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.MaybeStrArray')
    L = out_node.fields

    if self.strs:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.strs:
        x0.children.append(NewLeaf(i0, color_e.StringConst))
      L.append(field('strs', x0))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.MaybeStrArray')
    L = out_node.fields
    if self.strs:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.strs:
        x0.children.append(NewLeaf(i0, color_e.StringConst))
      L.append(field('strs', x0))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class value__AssocArray(value_t):
  tag = 4
  __slots__ = ('d',)

  def __init__(self, d=None):
    # type: (Optional[Any]) -> None
    self.d = d
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.AssocArray')
    L = out_node.fields

    x0 = hnode.External(self.d)
    L.append(field('d', x0))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.AssocArray')
    L = out_node.fields
    x0 = hnode.External(self.d)
    L.append(field('d', x0))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class value__Obj(value_t):
  tag = 5
  __slots__ = ('obj',)

  def __init__(self, obj=None):
    # type: (Optional[Any]) -> None
    self.obj = obj
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.Obj')
    L = out_node.fields

    x0 = hnode.External(self.obj)
    L.append(field('obj', x0))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('value.Obj')
    L = out_node.fields
    x0 = hnode.External(self.obj)
    L.append(field('obj', x0))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class value(object):
  Undef = value__Undef
  Str = value__Str
  MaybeStrArray = value__MaybeStrArray
  AssocArray = value__AssocArray
  Obj = value__Obj

class var_flags_t(pybase.SimpleObj):
  pass

class var_flags_e(object):
  Exported = var_flags_t(1)
  ReadOnly = var_flags_t(2)

_var_flags_str = {
  1: 'var_flags.Exported',
  2: 'var_flags.ReadOnly',
}

def var_flags_str(val):
  # type: (var_flags_t) -> str
  return _var_flags_str[val]

class scope_t(pybase.SimpleObj):
  pass

class scope_e(object):
  LocalOnly = scope_t(1)
  GlobalOnly = scope_t(2)
  Dynamic = scope_t(3)

_scope_str = {
  1: 'scope.LocalOnly',
  2: 'scope.GlobalOnly',
  3: 'scope.Dynamic',
}

def scope_str(val):
  # type: (scope_t) -> str
  return _scope_str[val]

class lvalue_e(object):
  Named = 1
  Indexed = 2
  Keyed = 3
  ObjIndex = 4
  ObjAttr = 5

_lvalue_str = {
  1: 'lvalue.Named',
  2: 'lvalue.Indexed',
  3: 'lvalue.Keyed',
  4: 'lvalue.ObjIndex',
  5: 'lvalue.ObjAttr',
}

def lvalue_str(tag):
  # type: (int) -> str
  return _lvalue_str[tag]

class lvalue_t(pybase.CompoundObj):
  def tag_(self):
    # type: () -> int
    return self.tag
  pass

class lvalue__Named(lvalue_t):
  tag = 1
  __slots__ = ('name', 'spids')

  def __init__(self, name=None, spids=None):
    # type: (Optional[str], Optional[List[int]]) -> None
    self.name = name
    self.spids = spids or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.Named')
    L = out_node.fields

    x0 = NewLeaf(self.name, color_e.StringConst)
    L.append(field('name', x0))

    if self.spids:  # ArrayType
      x1 = hnode.Array([])
      for i1 in self.spids:
        x1.children.append(hnode.Leaf(str(i1), color_e.OtherConst))
      L.append(field('spids', x1))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.Named')
    L = out_node.fields
    x0 = NewLeaf(self.name, color_e.StringConst)
    L.append(field('name', x0))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class lvalue__Indexed(lvalue_t):
  tag = 2
  __slots__ = ('name', 'index', 'spids')

  def __init__(self, name=None, index=None, spids=None):
    # type: (Optional[str], Optional[int], Optional[List[int]]) -> None
    self.name = name
    self.index = index
    self.spids = spids or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.Indexed')
    L = out_node.fields

    x0 = NewLeaf(self.name, color_e.StringConst)
    L.append(field('name', x0))

    x1 = hnode.Leaf(str(self.index), color_e.OtherConst)
    L.append(field('index', x1))

    if self.spids:  # ArrayType
      x2 = hnode.Array([])
      for i2 in self.spids:
        x2.children.append(hnode.Leaf(str(i2), color_e.OtherConst))
      L.append(field('spids', x2))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.Indexed')
    L = out_node.fields
    x0 = NewLeaf(self.name, color_e.StringConst)
    L.append(field('name', x0))

    x1 = hnode.Leaf(str(self.index), color_e.OtherConst)
    L.append(field('index', x1))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class lvalue__Keyed(lvalue_t):
  tag = 3
  __slots__ = ('name', 'key', 'spids')

  def __init__(self, name=None, key=None, spids=None):
    # type: (Optional[str], Optional[str], Optional[List[int]]) -> None
    self.name = name
    self.key = key
    self.spids = spids or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.Keyed')
    L = out_node.fields

    x0 = NewLeaf(self.name, color_e.StringConst)
    L.append(field('name', x0))

    x1 = NewLeaf(self.key, color_e.StringConst)
    L.append(field('key', x1))

    if self.spids:  # ArrayType
      x2 = hnode.Array([])
      for i2 in self.spids:
        x2.children.append(hnode.Leaf(str(i2), color_e.OtherConst))
      L.append(field('spids', x2))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.Keyed')
    L = out_node.fields
    x0 = NewLeaf(self.name, color_e.StringConst)
    L.append(field('name', x0))

    x1 = NewLeaf(self.key, color_e.StringConst)
    L.append(field('key', x1))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class lvalue__ObjIndex(lvalue_t):
  tag = 4
  __slots__ = ('obj', 'index', 'spids')

  def __init__(self, obj=None, index=None, spids=None):
    # type: (Optional[Any], Optional[Any], Optional[List[int]]) -> None
    self.obj = obj
    self.index = index
    self.spids = spids or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.ObjIndex')
    L = out_node.fields

    x0 = hnode.External(self.obj)
    L.append(field('obj', x0))

    x1 = hnode.External(self.index)
    L.append(field('index', x1))

    if self.spids:  # ArrayType
      x2 = hnode.Array([])
      for i2 in self.spids:
        x2.children.append(hnode.Leaf(str(i2), color_e.OtherConst))
      L.append(field('spids', x2))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.ObjIndex')
    L = out_node.fields
    x0 = hnode.External(self.obj)
    L.append(field('obj', x0))

    x1 = hnode.External(self.index)
    L.append(field('index', x1))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class lvalue__ObjAttr(lvalue_t):
  tag = 5
  __slots__ = ('obj', 'attr', 'spids')

  def __init__(self, obj=None, attr=None, spids=None):
    # type: (Optional[Any], Optional[str], Optional[List[int]]) -> None
    self.obj = obj
    self.attr = attr
    self.spids = spids or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.ObjAttr')
    L = out_node.fields

    x0 = hnode.External(self.obj)
    L.append(field('obj', x0))

    x1 = NewLeaf(self.attr, color_e.StringConst)
    L.append(field('attr', x1))

    if self.spids:  # ArrayType
      x2 = hnode.Array([])
      for i2 in self.spids:
        x2.children.append(hnode.Leaf(str(i2), color_e.OtherConst))
      L.append(field('spids', x2))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('lvalue.ObjAttr')
    L = out_node.fields
    x0 = hnode.External(self.obj)
    L.append(field('obj', x0))

    x1 = NewLeaf(self.attr, color_e.StringConst)
    L.append(field('attr', x1))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class lvalue(object):
  Named = lvalue__Named
  Indexed = lvalue__Indexed
  Keyed = lvalue__Keyed
  ObjIndex = lvalue__ObjIndex
  ObjAttr = lvalue__ObjAttr

class redirect_e(object):
  Path = 1
  FileDesc = 2
  HereDoc = 3

_redirect_str = {
  1: 'redirect.Path',
  2: 'redirect.FileDesc',
  3: 'redirect.HereDoc',
}

def redirect_str(tag):
  # type: (int) -> str
  return _redirect_str[tag]

class redirect_t(pybase.CompoundObj):
  def tag_(self):
    # type: () -> int
    return self.tag
  pass

class redirect__Path(redirect_t):
  tag = 1
  __slots__ = ('op_id', 'fd', 'filename', 'op_spid')

  def __init__(self, op_id=None, fd=None, filename=None, op_spid=None):
    # type: (Optional[Id_t], Optional[int], Optional[str], Optional[int]) -> None
    self.op_id = op_id
    self.fd = fd
    self.filename = filename
    self.op_spid = op_spid
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('redirect.Path')
    L = out_node.fields

    assert self.op_id is not None
    x0 = hnode.Leaf(Id_str(self.op_id), color_e.UserType)
    L.append(field('op_id', x0))

    x1 = hnode.Leaf(str(self.fd), color_e.OtherConst)
    L.append(field('fd', x1))

    x2 = NewLeaf(self.filename, color_e.StringConst)
    L.append(field('filename', x2))

    x3 = hnode.Leaf(str(self.op_spid), color_e.OtherConst)
    L.append(field('op_spid', x3))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('redirect.Path')
    L = out_node.fields
    assert self.op_id is not None
    x0 = hnode.Leaf(Id_str(self.op_id), color_e.UserType)
    L.append(field('op_id', x0))

    x1 = hnode.Leaf(str(self.fd), color_e.OtherConst)
    L.append(field('fd', x1))

    x2 = NewLeaf(self.filename, color_e.StringConst)
    L.append(field('filename', x2))

    x3 = hnode.Leaf(str(self.op_spid), color_e.OtherConst)
    L.append(field('op_spid', x3))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class redirect__FileDesc(redirect_t):
  tag = 2
  __slots__ = ('op_id', 'fd', 'target_fd', 'op_spid')

  def __init__(self, op_id=None, fd=None, target_fd=None, op_spid=None):
    # type: (Optional[Id_t], Optional[int], Optional[int], Optional[int]) -> None
    self.op_id = op_id
    self.fd = fd
    self.target_fd = target_fd
    self.op_spid = op_spid
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('redirect.FileDesc')
    L = out_node.fields

    assert self.op_id is not None
    x0 = hnode.Leaf(Id_str(self.op_id), color_e.UserType)
    L.append(field('op_id', x0))

    x1 = hnode.Leaf(str(self.fd), color_e.OtherConst)
    L.append(field('fd', x1))

    x2 = hnode.Leaf(str(self.target_fd), color_e.OtherConst)
    L.append(field('target_fd', x2))

    x3 = hnode.Leaf(str(self.op_spid), color_e.OtherConst)
    L.append(field('op_spid', x3))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('redirect.FileDesc')
    L = out_node.fields
    assert self.op_id is not None
    x0 = hnode.Leaf(Id_str(self.op_id), color_e.UserType)
    L.append(field('op_id', x0))

    x1 = hnode.Leaf(str(self.fd), color_e.OtherConst)
    L.append(field('fd', x1))

    x2 = hnode.Leaf(str(self.target_fd), color_e.OtherConst)
    L.append(field('target_fd', x2))

    x3 = hnode.Leaf(str(self.op_spid), color_e.OtherConst)
    L.append(field('op_spid', x3))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class redirect__HereDoc(redirect_t):
  tag = 3
  __slots__ = ('fd', 'body', 'op_spid')

  def __init__(self, fd=None, body=None, op_spid=None):
    # type: (Optional[int], Optional[str], Optional[int]) -> None
    self.fd = fd
    self.body = body
    self.op_spid = op_spid
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('redirect.HereDoc')
    L = out_node.fields

    x0 = hnode.Leaf(str(self.fd), color_e.OtherConst)
    L.append(field('fd', x0))

    x1 = NewLeaf(self.body, color_e.StringConst)
    L.append(field('body', x1))

    x2 = hnode.Leaf(str(self.op_spid), color_e.OtherConst)
    L.append(field('op_spid', x2))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('redirect.HereDoc')
    L = out_node.fields
    x0 = hnode.Leaf(str(self.fd), color_e.OtherConst)
    L.append(field('fd', x0))

    x1 = NewLeaf(self.body, color_e.StringConst)
    L.append(field('body', x1))

    x2 = hnode.Leaf(str(self.op_spid), color_e.OtherConst)
    L.append(field('op_spid', x2))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class redirect(object):
  Path = redirect__Path
  FileDesc = redirect__FileDesc
  HereDoc = redirect__HereDoc

class job_status_e(object):
  Process = 1
  Pipeline = 2

_job_status_str = {
  1: 'job_status.Process',
  2: 'job_status.Pipeline',
}

def job_status_str(tag):
  # type: (int) -> str
  return _job_status_str[tag]

class job_status_t(pybase.CompoundObj):
  def tag_(self):
    # type: () -> int
    return self.tag
  pass

class job_status__Process(job_status_t):
  tag = 1
  __slots__ = ('status',)

  def __init__(self, status=None):
    # type: (Optional[int]) -> None
    self.status = status
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('job_status.Process')
    L = out_node.fields

    x0 = hnode.Leaf(str(self.status), color_e.OtherConst)
    L.append(field('status', x0))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('job_status.Process')
    L = out_node.fields
    x0 = hnode.Leaf(str(self.status), color_e.OtherConst)
    L.append(field('status', x0))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class job_status__Pipeline(job_status_t):
  tag = 2
  __slots__ = ('statuses',)

  def __init__(self, statuses=None):
    # type: (Optional[List[int]]) -> None
    self.statuses = statuses or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('job_status.Pipeline')
    L = out_node.fields

    if self.statuses:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.statuses:
        x0.children.append(hnode.Leaf(str(i0), color_e.OtherConst))
      L.append(field('statuses', x0))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('job_status.Pipeline')
    L = out_node.fields
    if self.statuses:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.statuses:
        x0.children.append(hnode.Leaf(str(i0), color_e.OtherConst))
      L.append(field('statuses', x0))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class job_status(object):
  Process = job_status__Process
  Pipeline = job_status__Pipeline

class span_t(pybase.SimpleObj):
  pass

class span_e(object):
  Black = span_t(1)
  Delim = span_t(2)
  Backslash = span_t(3)

_span_str = {
  1: 'span.Black',
  2: 'span.Delim',
  3: 'span.Backslash',
}

def span_str(val):
  # type: (span_t) -> str
  return _span_str[val]

class emit_t(pybase.SimpleObj):
  pass

class emit_e(object):
  Part = emit_t(1)
  Delim = emit_t(2)
  Empty = emit_t(3)
  Escape = emit_t(4)
  Nothing = emit_t(5)

_emit_str = {
  1: 'emit.Part',
  2: 'emit.Delim',
  3: 'emit.Empty',
  4: 'emit.Escape',
  5: 'emit.Nothing',
}

def emit_str(val):
  # type: (emit_t) -> str
  return _emit_str[val]

class state_t(pybase.SimpleObj):
  pass

class state_e(object):
  Invalid = state_t(1)
  Start = state_t(2)
  DE_White1 = state_t(3)
  DE_Gray = state_t(4)
  DE_White2 = state_t(5)
  Black = state_t(6)
  Backslash = state_t(7)

_state_str = {
  1: 'state.Invalid',
  2: 'state.Start',
  3: 'state.DE_White1',
  4: 'state.DE_Gray',
  5: 'state.DE_White2',
  6: 'state.Black',
  7: 'state.Backslash',
}

def state_str(val):
  # type: (state_t) -> str
  return _state_str[val]

class char_kind_t(pybase.SimpleObj):
  pass

class char_kind_e(object):
  DE_White = char_kind_t(1)
  DE_Gray = char_kind_t(2)
  Black = char_kind_t(3)
  Backslash = char_kind_t(4)

_char_kind_str = {
  1: 'char_kind.DE_White',
  2: 'char_kind.DE_Gray',
  3: 'char_kind.Black',
  4: 'char_kind.Backslash',
}

def char_kind_str(val):
  # type: (char_kind_t) -> str
  return _char_kind_str[val]

class effect_t(pybase.SimpleObj):
  pass

class effect_e(object):
  SpliceParts = effect_t(1)
  Error = effect_t(2)
  SpliceAndAssign = effect_t(3)
  NoOp = effect_t(4)

_effect_str = {
  1: 'effect.SpliceParts',
  2: 'effect.Error',
  3: 'effect.SpliceAndAssign',
  4: 'effect.NoOp',
}

def effect_str(val):
  # type: (effect_t) -> str
  return _effect_str[val]

class job_state_t(pybase.SimpleObj):
  pass

class job_state_e(object):
  Running = job_state_t(1)
  Done = job_state_t(2)
  Stopped = job_state_t(3)

_job_state_str = {
  1: 'job_state.Running',
  2: 'job_state.Done',
  3: 'job_state.Stopped',
}

def job_state_str(val):
  # type: (job_state_t) -> str
  return _job_state_str[val]

class word_style_t(pybase.SimpleObj):
  pass

class word_style_e(object):
  Expr = word_style_t(1)
  Unquoted = word_style_t(2)
  DQ = word_style_t(3)
  SQ = word_style_t(4)

_word_style_str = {
  1: 'word_style.Expr',
  2: 'word_style.Unquoted',
  3: 'word_style.DQ',
  4: 'word_style.SQ',
}

def word_style_str(val):
  # type: (word_style_t) -> str
  return _word_style_str[val]

class assign_arg(pybase.CompoundObj):
  tag = 1000
  __slots__ = ('lval', 'rval', 'spid')

  def __init__(self, lval=None, rval=None, spid=None):
    # type: (Optional[lvalue_t], Optional[value_t], Optional[int]) -> None
    self.lval = lval
    self.rval = rval or None
    self.spid = spid
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('assign_arg')
    L = out_node.fields

    assert self.lval is not None
    x0 = self.lval.PrettyTree()
    L.append(field('lval', x0))

    if self.rval is not None:  # MaybeType
      x1 = self.rval.PrettyTree()
      L.append(field('rval', x1))

    x2 = hnode.Leaf(str(self.spid), color_e.OtherConst)
    L.append(field('spid', x2))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('assign_arg')
    L = out_node.fields
    assert self.lval is not None
    x0 = self.lval.AbbreviatedTree()
    L.append(field('lval', x0))

    if self.rval is not None:  # MaybeType
      x1 = self.rval.AbbreviatedTree()
      L.append(field('rval', x1))

    x2 = hnode.Leaf(str(self.spid), color_e.OtherConst)
    L.append(field('spid', x2))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class arg_vector(pybase.CompoundObj):
  tag = 1001
  __slots__ = ('strs', 'spids')

  def __init__(self, strs=None, spids=None):
    # type: (Optional[List[str]], Optional[List[int]]) -> None
    self.strs = strs or []
    self.spids = spids or []
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('arg_vector')
    L = out_node.fields

    if self.strs:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.strs:
        x0.children.append(NewLeaf(i0, color_e.StringConst))
      L.append(field('strs', x0))

    if self.spids:  # ArrayType
      x1 = hnode.Array([])
      for i1 in self.spids:
        x1.children.append(hnode.Leaf(str(i1), color_e.OtherConst))
      L.append(field('spids', x1))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('arg_vector')
    L = out_node.fields
    if self.strs:  # ArrayType
      x0 = hnode.Array([])
      for i0 in self.strs:
        x0.children.append(NewLeaf(i0, color_e.StringConst))
      L.append(field('strs', x0))

    if self.spids:  # ArrayType
      x1 = hnode.Array([])
      for i1 in self.spids:
        x1.children.append(hnode.Leaf(str(i1), color_e.OtherConst))
      L.append(field('spids', x1))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

class cell(pybase.CompoundObj):
  tag = 1002
  __slots__ = ('val', 'exported', 'readonly')

  def __init__(self, val=None, exported=None, readonly=None):
    # type: (Optional[value_t], Optional[bool], Optional[bool]) -> None
    self.val = val
    self.exported = exported
    self.readonly = readonly
  def PrettyTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('cell')
    L = out_node.fields

    assert self.val is not None
    x0 = self.val.PrettyTree()
    L.append(field('val', x0))

    x1 = hnode.Leaf('T' if self.exported else 'F', color_e.OtherConst)
    L.append(field('exported', x1))

    x2 = hnode.Leaf('T' if self.readonly else 'F', color_e.OtherConst)
    L.append(field('readonly', x2))

    return out_node

  def _AbbreviatedTree(self):
    # type: () -> hnode_t
    out_node = NewRecord('cell')
    L = out_node.fields
    assert self.val is not None
    x0 = self.val.AbbreviatedTree()
    L.append(field('val', x0))

    x1 = hnode.Leaf('T' if self.exported else 'F', color_e.OtherConst)
    L.append(field('exported', x1))

    x2 = hnode.Leaf('T' if self.readonly else 'F', color_e.OtherConst)
    L.append(field('readonly', x2))

    return out_node

  def AbbreviatedTree(self):
    # type: () -> hnode_t
    return self._AbbreviatedTree()

