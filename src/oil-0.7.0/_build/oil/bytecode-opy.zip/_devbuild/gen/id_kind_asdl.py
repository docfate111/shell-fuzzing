from asdl import pybase
from typing import List

Id_t = int  # type alias for integer

class Id(object):
  Word_Compound = 1
  Arith_Semi = 2
  Arith_Comma = 3
  Arith_Plus = 4
  Arith_Minus = 5
  Arith_Star = 6
  Arith_Slash = 7
  Arith_Percent = 8
  Arith_DPlus = 9
  Arith_DMinus = 10
  Arith_DStar = 11
  Arith_LParen = 12
  Arith_RParen = 13
  Arith_LBracket = 14
  Arith_RBracket = 15
  Arith_RBrace = 16
  Arith_QMark = 17
  Arith_Colon = 18
  Arith_LessEqual = 19
  Arith_Less = 20
  Arith_GreatEqual = 21
  Arith_Great = 22
  Arith_DEqual = 23
  Arith_NEqual = 24
  Arith_DAmp = 25
  Arith_DPipe = 26
  Arith_Bang = 27
  Arith_DGreat = 28
  Arith_DLess = 29
  Arith_Amp = 30
  Arith_Pipe = 31
  Arith_Caret = 32
  Arith_Tilde = 33
  Arith_Equal = 34
  Arith_PlusEqual = 35
  Arith_MinusEqual = 36
  Arith_StarEqual = 37
  Arith_SlashEqual = 38
  Arith_PercentEqual = 39
  Arith_DGreatEqual = 40
  Arith_DLessEqual = 41
  Arith_AmpEqual = 42
  Arith_PipeEqual = 43
  Arith_CaretEqual = 44
  Eof_Real = 45
  Eof_RParen = 46
  Eof_Backtick = 47
  Undefined_Tok = 48
  Unknown_Tok = 49
  Eol_Tok = 50
  Ignored_LineCont = 51
  Ignored_Space = 52
  Ignored_Comment = 53
  WS_Space = 54
  Lit_Chars = 55
  Lit_VarLike = 56
  Lit_ArrayLhsOpen = 57
  Lit_ArrayLhsClose = 58
  Lit_Splice = 59
  Lit_Other = 60
  Lit_EscapedChar = 61
  Lit_RegexMeta = 62
  Lit_LBracket = 63
  Lit_RBracket = 64
  Lit_Star = 65
  Lit_QMark = 66
  Lit_LBrace = 67
  Lit_RBrace = 68
  Lit_Comma = 69
  Lit_Equals = 70
  Lit_DRightBracket = 71
  Lit_TildeLike = 72
  Lit_Pound = 73
  Lit_Slash = 74
  Lit_Percent = 75
  Lit_Digits = 76
  Lit_At = 77
  Lit_ArithVarLike = 78
  Lit_CompDummy = 79
  Backtick_Right = 80
  Backtick_Quoted = 81
  Backtick_Other = 82
  History_Op = 83
  History_Num = 84
  History_Search = 85
  History_Other = 86
  Op_Newline = 87
  Op_Amp = 88
  Op_Pipe = 89
  Op_PipeAmp = 90
  Op_DAmp = 91
  Op_DPipe = 92
  Op_Semi = 93
  Op_DSemi = 94
  Op_LParen = 95
  Op_RParen = 96
  Op_DLeftParen = 97
  Op_DRightParen = 98
  Op_Less = 99
  Op_Great = 100
  Op_Bang = 101
  Op_LBracket = 102
  Op_RBracket = 103
  Op_LBrace = 104
  Op_RBrace = 105
  Expr_Reserved = 106
  Expr_Symbol = 107
  Expr_Name = 108
  Expr_DecInt = 109
  Expr_BinInt = 110
  Expr_OctInt = 111
  Expr_HexInt = 112
  Expr_Float = 113
  Expr_Dot = 114
  Expr_DColon = 115
  Expr_RArrow = 116
  Expr_RDArrow = 117
  Expr_At = 118
  Expr_DoubleAt = 119
  Expr_Ellipsis = 120
  Expr_Dollar = 121
  Expr_NotTilde = 122
  Expr_CastedDummy = 123
  Expr_Null = 124
  Expr_True = 125
  Expr_False = 126
  Expr_Div = 127
  Expr_Mod = 128
  Expr_Xor = 129
  Expr_And = 130
  Expr_Or = 131
  Expr_Not = 132
  Expr_For = 133
  Expr_Is = 134
  Expr_In = 135
  Expr_If = 136
  Expr_Else = 137
  Expr_Func = 138
  Char_OneChar = 139
  Char_Stop = 140
  Char_Hex = 141
  Char_Octal3 = 142
  Char_Octal4 = 143
  Char_Unicode4 = 144
  Char_Unicode8 = 145
  Char_Literals = 146
  Char_BadBackslash = 147
  Re_Start = 148
  Re_End = 149
  Re_Dot = 150
  Redir_Less = 151
  Redir_Great = 152
  Redir_DLess = 153
  Redir_TLess = 154
  Redir_DGreat = 155
  Redir_GreatAnd = 156
  Redir_LessAnd = 157
  Redir_DLessDash = 158
  Redir_LessGreat = 159
  Redir_Clobber = 160
  Redir_AndGreat = 161
  Redir_AndDGreat = 162
  Redir_GreatPlus = 163
  Redir_DGreatPlus = 164
  Left_DoubleQuote = 165
  Left_SingleQuoteRaw = 166
  Left_SingleQuoteC = 167
  Left_Backtick = 168
  Left_DollarParen = 169
  Left_DollarBrace = 170
  Left_DollarDParen = 171
  Left_DollarBracket = 172
  Left_DollarDoubleQuote = 173
  Left_ProcSubIn = 174
  Left_ProcSubOut = 175
  Left_AtBracket = 176
  Left_AtParen = 177
  Right_DoubleQuote = 178
  Right_SingleQuote = 179
  Right_Backtick = 180
  Right_DollarBrace = 181
  Right_DollarDParen = 182
  Right_DollarDoubleQuote = 183
  Right_DollarSingleQuote = 184
  Right_Subshell = 185
  Right_ShFunction = 186
  Right_CasePat = 187
  Right_ShArrayLiteral = 188
  Right_ExtGlob = 189
  ExtGlob_At = 190
  ExtGlob_Star = 191
  ExtGlob_Plus = 192
  ExtGlob_QMark = 193
  ExtGlob_Bang = 194
  VSub_DollarName = 195
  VSub_Name = 196
  VSub_Number = 197
  VSub_Bang = 198
  VSub_At = 199
  VSub_Pound = 200
  VSub_Dollar = 201
  VSub_Star = 202
  VSub_Hyphen = 203
  VSub_QMark = 204
  VTest_ColonHyphen = 205
  VTest_Hyphen = 206
  VTest_ColonEquals = 207
  VTest_Equals = 208
  VTest_ColonQMark = 209
  VTest_QMark = 210
  VTest_ColonPlus = 211
  VTest_Plus = 212
  VOp0_Q = 213
  VOp0_E = 214
  VOp0_P = 215
  VOp0_A = 216
  VOp0_a = 217
  VOp1_Percent = 218
  VOp1_DPercent = 219
  VOp1_Pound = 220
  VOp1_DPound = 221
  VOp1_Caret = 222
  VOp1_DCaret = 223
  VOp1_Comma = 224
  VOp1_DComma = 225
  VOp2_Slash = 226
  VOp2_Colon = 227
  VOp2_LBracket = 228
  VOp2_RBracket = 229
  VOp3_At = 230
  VOp3_Star = 231
  Node_PostDPlus = 232
  Node_PostDMinus = 233
  Node_UnaryPlus = 234
  Node_UnaryMinus = 235
  Node_NotIn = 236
  Node_IsNot = 237
  KW_DLeftBracket = 238
  KW_Bang = 239
  KW_For = 240
  KW_While = 241
  KW_Until = 242
  KW_Do = 243
  KW_Done = 244
  KW_In = 245
  KW_Case = 246
  KW_Esac = 247
  KW_If = 248
  KW_Fi = 249
  KW_Then = 250
  KW_Else = 251
  KW_Elif = 252
  KW_Function = 253
  KW_Time = 254
  KW_Const = 255
  KW_Set = 256
  KW_Var = 257
  KW_Auto = 258
  KW_SetVar = 259
  KW_Proc = 260
  KW_Func = 261
  KW_Pass = 262
  KW_Match = 263
  KW_With = 264
  KW_Switch = 265
  ControlFlow_Break = 266
  ControlFlow_Continue = 267
  ControlFlow_Return = 268
  ControlFlow_Exit = 269
  Glob_LBracket = 270
  Glob_RBracket = 271
  Glob_Star = 272
  Glob_QMark = 273
  Glob_Bang = 274
  Glob_Caret = 275
  Glob_EscapedChar = 276
  Glob_BadBackslash = 277
  Glob_CleanLiterals = 278
  Glob_OtherLiteral = 279
  Format_EscapedPercent = 280
  Format_Percent = 281
  Format_Flag = 282
  Format_Num = 283
  Format_Dot = 284
  Format_Type = 285
  PS_Subst = 286
  PS_Octal3 = 287
  PS_LBrace = 288
  PS_RBrace = 289
  PS_Literals = 290
  PS_BadBackslash = 291
  Range_Int = 292
  Range_Char = 293
  Range_Dots = 294
  Range_Other = 295
  BoolUnary_z = 296
  BoolUnary_n = 297
  BoolUnary_o = 298
  BoolUnary_t = 299
  BoolUnary_v = 300
  BoolUnary_R = 301
  BoolUnary_a = 302
  BoolUnary_b = 303
  BoolUnary_c = 304
  BoolUnary_d = 305
  BoolUnary_e = 306
  BoolUnary_f = 307
  BoolUnary_g = 308
  BoolUnary_h = 309
  BoolUnary_L = 310
  BoolUnary_p = 311
  BoolUnary_r = 312
  BoolUnary_s = 313
  BoolUnary_S = 314
  BoolUnary_u = 315
  BoolUnary_w = 316
  BoolUnary_x = 317
  BoolUnary_O = 318
  BoolUnary_G = 319
  BoolUnary_N = 320
  BoolBinary_GlobEqual = 321
  BoolBinary_GlobDEqual = 322
  BoolBinary_GlobNEqual = 323
  BoolBinary_EqualTilde = 324
  BoolBinary_ef = 325
  BoolBinary_nt = 326
  BoolBinary_ot = 327
  BoolBinary_eq = 328
  BoolBinary_ne = 329
  BoolBinary_gt = 330
  BoolBinary_ge = 331
  BoolBinary_lt = 332
  BoolBinary_le = 333
  BoolBinary_Equal = 334
  BoolBinary_DEqual = 335
  BoolBinary_NEqual = 336

_Id_str = {
  1: 'Id.Word_Compound',
  2: 'Id.Arith_Semi',
  3: 'Id.Arith_Comma',
  4: 'Id.Arith_Plus',
  5: 'Id.Arith_Minus',
  6: 'Id.Arith_Star',
  7: 'Id.Arith_Slash',
  8: 'Id.Arith_Percent',
  9: 'Id.Arith_DPlus',
  10: 'Id.Arith_DMinus',
  11: 'Id.Arith_DStar',
  12: 'Id.Arith_LParen',
  13: 'Id.Arith_RParen',
  14: 'Id.Arith_LBracket',
  15: 'Id.Arith_RBracket',
  16: 'Id.Arith_RBrace',
  17: 'Id.Arith_QMark',
  18: 'Id.Arith_Colon',
  19: 'Id.Arith_LessEqual',
  20: 'Id.Arith_Less',
  21: 'Id.Arith_GreatEqual',
  22: 'Id.Arith_Great',
  23: 'Id.Arith_DEqual',
  24: 'Id.Arith_NEqual',
  25: 'Id.Arith_DAmp',
  26: 'Id.Arith_DPipe',
  27: 'Id.Arith_Bang',
  28: 'Id.Arith_DGreat',
  29: 'Id.Arith_DLess',
  30: 'Id.Arith_Amp',
  31: 'Id.Arith_Pipe',
  32: 'Id.Arith_Caret',
  33: 'Id.Arith_Tilde',
  34: 'Id.Arith_Equal',
  35: 'Id.Arith_PlusEqual',
  36: 'Id.Arith_MinusEqual',
  37: 'Id.Arith_StarEqual',
  38: 'Id.Arith_SlashEqual',
  39: 'Id.Arith_PercentEqual',
  40: 'Id.Arith_DGreatEqual',
  41: 'Id.Arith_DLessEqual',
  42: 'Id.Arith_AmpEqual',
  43: 'Id.Arith_PipeEqual',
  44: 'Id.Arith_CaretEqual',
  45: 'Id.Eof_Real',
  46: 'Id.Eof_RParen',
  47: 'Id.Eof_Backtick',
  48: 'Id.Undefined_Tok',
  49: 'Id.Unknown_Tok',
  50: 'Id.Eol_Tok',
  51: 'Id.Ignored_LineCont',
  52: 'Id.Ignored_Space',
  53: 'Id.Ignored_Comment',
  54: 'Id.WS_Space',
  55: 'Id.Lit_Chars',
  56: 'Id.Lit_VarLike',
  57: 'Id.Lit_ArrayLhsOpen',
  58: 'Id.Lit_ArrayLhsClose',
  59: 'Id.Lit_Splice',
  60: 'Id.Lit_Other',
  61: 'Id.Lit_EscapedChar',
  62: 'Id.Lit_RegexMeta',
  63: 'Id.Lit_LBracket',
  64: 'Id.Lit_RBracket',
  65: 'Id.Lit_Star',
  66: 'Id.Lit_QMark',
  67: 'Id.Lit_LBrace',
  68: 'Id.Lit_RBrace',
  69: 'Id.Lit_Comma',
  70: 'Id.Lit_Equals',
  71: 'Id.Lit_DRightBracket',
  72: 'Id.Lit_TildeLike',
  73: 'Id.Lit_Pound',
  74: 'Id.Lit_Slash',
  75: 'Id.Lit_Percent',
  76: 'Id.Lit_Digits',
  77: 'Id.Lit_At',
  78: 'Id.Lit_ArithVarLike',
  79: 'Id.Lit_CompDummy',
  80: 'Id.Backtick_Right',
  81: 'Id.Backtick_Quoted',
  82: 'Id.Backtick_Other',
  83: 'Id.History_Op',
  84: 'Id.History_Num',
  85: 'Id.History_Search',
  86: 'Id.History_Other',
  87: 'Id.Op_Newline',
  88: 'Id.Op_Amp',
  89: 'Id.Op_Pipe',
  90: 'Id.Op_PipeAmp',
  91: 'Id.Op_DAmp',
  92: 'Id.Op_DPipe',
  93: 'Id.Op_Semi',
  94: 'Id.Op_DSemi',
  95: 'Id.Op_LParen',
  96: 'Id.Op_RParen',
  97: 'Id.Op_DLeftParen',
  98: 'Id.Op_DRightParen',
  99: 'Id.Op_Less',
  100: 'Id.Op_Great',
  101: 'Id.Op_Bang',
  102: 'Id.Op_LBracket',
  103: 'Id.Op_RBracket',
  104: 'Id.Op_LBrace',
  105: 'Id.Op_RBrace',
  106: 'Id.Expr_Reserved',
  107: 'Id.Expr_Symbol',
  108: 'Id.Expr_Name',
  109: 'Id.Expr_DecInt',
  110: 'Id.Expr_BinInt',
  111: 'Id.Expr_OctInt',
  112: 'Id.Expr_HexInt',
  113: 'Id.Expr_Float',
  114: 'Id.Expr_Dot',
  115: 'Id.Expr_DColon',
  116: 'Id.Expr_RArrow',
  117: 'Id.Expr_RDArrow',
  118: 'Id.Expr_At',
  119: 'Id.Expr_DoubleAt',
  120: 'Id.Expr_Ellipsis',
  121: 'Id.Expr_Dollar',
  122: 'Id.Expr_NotTilde',
  123: 'Id.Expr_CastedDummy',
  124: 'Id.Expr_Null',
  125: 'Id.Expr_True',
  126: 'Id.Expr_False',
  127: 'Id.Expr_Div',
  128: 'Id.Expr_Mod',
  129: 'Id.Expr_Xor',
  130: 'Id.Expr_And',
  131: 'Id.Expr_Or',
  132: 'Id.Expr_Not',
  133: 'Id.Expr_For',
  134: 'Id.Expr_Is',
  135: 'Id.Expr_In',
  136: 'Id.Expr_If',
  137: 'Id.Expr_Else',
  138: 'Id.Expr_Func',
  139: 'Id.Char_OneChar',
  140: 'Id.Char_Stop',
  141: 'Id.Char_Hex',
  142: 'Id.Char_Octal3',
  143: 'Id.Char_Octal4',
  144: 'Id.Char_Unicode4',
  145: 'Id.Char_Unicode8',
  146: 'Id.Char_Literals',
  147: 'Id.Char_BadBackslash',
  148: 'Id.Re_Start',
  149: 'Id.Re_End',
  150: 'Id.Re_Dot',
  151: 'Id.Redir_Less',
  152: 'Id.Redir_Great',
  153: 'Id.Redir_DLess',
  154: 'Id.Redir_TLess',
  155: 'Id.Redir_DGreat',
  156: 'Id.Redir_GreatAnd',
  157: 'Id.Redir_LessAnd',
  158: 'Id.Redir_DLessDash',
  159: 'Id.Redir_LessGreat',
  160: 'Id.Redir_Clobber',
  161: 'Id.Redir_AndGreat',
  162: 'Id.Redir_AndDGreat',
  163: 'Id.Redir_GreatPlus',
  164: 'Id.Redir_DGreatPlus',
  165: 'Id.Left_DoubleQuote',
  166: 'Id.Left_SingleQuoteRaw',
  167: 'Id.Left_SingleQuoteC',
  168: 'Id.Left_Backtick',
  169: 'Id.Left_DollarParen',
  170: 'Id.Left_DollarBrace',
  171: 'Id.Left_DollarDParen',
  172: 'Id.Left_DollarBracket',
  173: 'Id.Left_DollarDoubleQuote',
  174: 'Id.Left_ProcSubIn',
  175: 'Id.Left_ProcSubOut',
  176: 'Id.Left_AtBracket',
  177: 'Id.Left_AtParen',
  178: 'Id.Right_DoubleQuote',
  179: 'Id.Right_SingleQuote',
  180: 'Id.Right_Backtick',
  181: 'Id.Right_DollarBrace',
  182: 'Id.Right_DollarDParen',
  183: 'Id.Right_DollarDoubleQuote',
  184: 'Id.Right_DollarSingleQuote',
  185: 'Id.Right_Subshell',
  186: 'Id.Right_ShFunction',
  187: 'Id.Right_CasePat',
  188: 'Id.Right_ShArrayLiteral',
  189: 'Id.Right_ExtGlob',
  190: 'Id.ExtGlob_At',
  191: 'Id.ExtGlob_Star',
  192: 'Id.ExtGlob_Plus',
  193: 'Id.ExtGlob_QMark',
  194: 'Id.ExtGlob_Bang',
  195: 'Id.VSub_DollarName',
  196: 'Id.VSub_Name',
  197: 'Id.VSub_Number',
  198: 'Id.VSub_Bang',
  199: 'Id.VSub_At',
  200: 'Id.VSub_Pound',
  201: 'Id.VSub_Dollar',
  202: 'Id.VSub_Star',
  203: 'Id.VSub_Hyphen',
  204: 'Id.VSub_QMark',
  205: 'Id.VTest_ColonHyphen',
  206: 'Id.VTest_Hyphen',
  207: 'Id.VTest_ColonEquals',
  208: 'Id.VTest_Equals',
  209: 'Id.VTest_ColonQMark',
  210: 'Id.VTest_QMark',
  211: 'Id.VTest_ColonPlus',
  212: 'Id.VTest_Plus',
  213: 'Id.VOp0_Q',
  214: 'Id.VOp0_E',
  215: 'Id.VOp0_P',
  216: 'Id.VOp0_A',
  217: 'Id.VOp0_a',
  218: 'Id.VOp1_Percent',
  219: 'Id.VOp1_DPercent',
  220: 'Id.VOp1_Pound',
  221: 'Id.VOp1_DPound',
  222: 'Id.VOp1_Caret',
  223: 'Id.VOp1_DCaret',
  224: 'Id.VOp1_Comma',
  225: 'Id.VOp1_DComma',
  226: 'Id.VOp2_Slash',
  227: 'Id.VOp2_Colon',
  228: 'Id.VOp2_LBracket',
  229: 'Id.VOp2_RBracket',
  230: 'Id.VOp3_At',
  231: 'Id.VOp3_Star',
  232: 'Id.Node_PostDPlus',
  233: 'Id.Node_PostDMinus',
  234: 'Id.Node_UnaryPlus',
  235: 'Id.Node_UnaryMinus',
  236: 'Id.Node_NotIn',
  237: 'Id.Node_IsNot',
  238: 'Id.KW_DLeftBracket',
  239: 'Id.KW_Bang',
  240: 'Id.KW_For',
  241: 'Id.KW_While',
  242: 'Id.KW_Until',
  243: 'Id.KW_Do',
  244: 'Id.KW_Done',
  245: 'Id.KW_In',
  246: 'Id.KW_Case',
  247: 'Id.KW_Esac',
  248: 'Id.KW_If',
  249: 'Id.KW_Fi',
  250: 'Id.KW_Then',
  251: 'Id.KW_Else',
  252: 'Id.KW_Elif',
  253: 'Id.KW_Function',
  254: 'Id.KW_Time',
  255: 'Id.KW_Const',
  256: 'Id.KW_Set',
  257: 'Id.KW_Var',
  258: 'Id.KW_Auto',
  259: 'Id.KW_SetVar',
  260: 'Id.KW_Proc',
  261: 'Id.KW_Func',
  262: 'Id.KW_Pass',
  263: 'Id.KW_Match',
  264: 'Id.KW_With',
  265: 'Id.KW_Switch',
  266: 'Id.ControlFlow_Break',
  267: 'Id.ControlFlow_Continue',
  268: 'Id.ControlFlow_Return',
  269: 'Id.ControlFlow_Exit',
  270: 'Id.Glob_LBracket',
  271: 'Id.Glob_RBracket',
  272: 'Id.Glob_Star',
  273: 'Id.Glob_QMark',
  274: 'Id.Glob_Bang',
  275: 'Id.Glob_Caret',
  276: 'Id.Glob_EscapedChar',
  277: 'Id.Glob_BadBackslash',
  278: 'Id.Glob_CleanLiterals',
  279: 'Id.Glob_OtherLiteral',
  280: 'Id.Format_EscapedPercent',
  281: 'Id.Format_Percent',
  282: 'Id.Format_Flag',
  283: 'Id.Format_Num',
  284: 'Id.Format_Dot',
  285: 'Id.Format_Type',
  286: 'Id.PS_Subst',
  287: 'Id.PS_Octal3',
  288: 'Id.PS_LBrace',
  289: 'Id.PS_RBrace',
  290: 'Id.PS_Literals',
  291: 'Id.PS_BadBackslash',
  292: 'Id.Range_Int',
  293: 'Id.Range_Char',
  294: 'Id.Range_Dots',
  295: 'Id.Range_Other',
  296: 'Id.BoolUnary_z',
  297: 'Id.BoolUnary_n',
  298: 'Id.BoolUnary_o',
  299: 'Id.BoolUnary_t',
  300: 'Id.BoolUnary_v',
  301: 'Id.BoolUnary_R',
  302: 'Id.BoolUnary_a',
  303: 'Id.BoolUnary_b',
  304: 'Id.BoolUnary_c',
  305: 'Id.BoolUnary_d',
  306: 'Id.BoolUnary_e',
  307: 'Id.BoolUnary_f',
  308: 'Id.BoolUnary_g',
  309: 'Id.BoolUnary_h',
  310: 'Id.BoolUnary_L',
  311: 'Id.BoolUnary_p',
  312: 'Id.BoolUnary_r',
  313: 'Id.BoolUnary_s',
  314: 'Id.BoolUnary_S',
  315: 'Id.BoolUnary_u',
  316: 'Id.BoolUnary_w',
  317: 'Id.BoolUnary_x',
  318: 'Id.BoolUnary_O',
  319: 'Id.BoolUnary_G',
  320: 'Id.BoolUnary_N',
  321: 'Id.BoolBinary_GlobEqual',
  322: 'Id.BoolBinary_GlobDEqual',
  323: 'Id.BoolBinary_GlobNEqual',
  324: 'Id.BoolBinary_EqualTilde',
  325: 'Id.BoolBinary_ef',
  326: 'Id.BoolBinary_nt',
  327: 'Id.BoolBinary_ot',
  328: 'Id.BoolBinary_eq',
  329: 'Id.BoolBinary_ne',
  330: 'Id.BoolBinary_gt',
  331: 'Id.BoolBinary_ge',
  332: 'Id.BoolBinary_lt',
  333: 'Id.BoolBinary_le',
  334: 'Id.BoolBinary_Equal',
  335: 'Id.BoolBinary_DEqual',
  336: 'Id.BoolBinary_NEqual',
}

def Id_str(val):
  # type: (Id_t) -> str
  return _Id_str[val]

class Kind_t(pybase.SimpleObj):
  pass

class Kind(object):
  Word = Kind_t(1)
  Arith = Kind_t(2)
  Eof = Kind_t(3)
  Undefined = Kind_t(4)
  Unknown = Kind_t(5)
  Eol = Kind_t(6)
  Ignored = Kind_t(7)
  WS = Kind_t(8)
  Lit = Kind_t(9)
  Backtick = Kind_t(10)
  History = Kind_t(11)
  Op = Kind_t(12)
  Expr = Kind_t(13)
  Char = Kind_t(14)
  Re = Kind_t(15)
  Redir = Kind_t(16)
  Left = Kind_t(17)
  Right = Kind_t(18)
  ExtGlob = Kind_t(19)
  VSub = Kind_t(20)
  VTest = Kind_t(21)
  VOp0 = Kind_t(22)
  VOp1 = Kind_t(23)
  VOp2 = Kind_t(24)
  VOp3 = Kind_t(25)
  Node = Kind_t(26)
  KW = Kind_t(27)
  ControlFlow = Kind_t(28)
  Glob = Kind_t(29)
  Format = Kind_t(30)
  PS = Kind_t(31)
  Range = Kind_t(32)
  BoolUnary = Kind_t(33)
  BoolBinary = Kind_t(34)

_Kind_str = {
  1: 'Kind.Word',
  2: 'Kind.Arith',
  3: 'Kind.Eof',
  4: 'Kind.Undefined',
  5: 'Kind.Unknown',
  6: 'Kind.Eol',
  7: 'Kind.Ignored',
  8: 'Kind.WS',
  9: 'Kind.Lit',
  10: 'Kind.Backtick',
  11: 'Kind.History',
  12: 'Kind.Op',
  13: 'Kind.Expr',
  14: 'Kind.Char',
  15: 'Kind.Re',
  16: 'Kind.Redir',
  17: 'Kind.Left',
  18: 'Kind.Right',
  19: 'Kind.ExtGlob',
  20: 'Kind.VSub',
  21: 'Kind.VTest',
  22: 'Kind.VOp0',
  23: 'Kind.VOp1',
  24: 'Kind.VOp2',
  25: 'Kind.VOp3',
  26: 'Kind.Node',
  27: 'Kind.KW',
  28: 'Kind.ControlFlow',
  29: 'Kind.Glob',
  30: 'Kind.Format',
  31: 'Kind.PS',
  32: 'Kind.Range',
  33: 'Kind.BoolUnary',
  34: 'Kind.BoolBinary',
}

def Kind_str(val):
  # type: (Kind_t) -> str
  return _Kind_str[val]

