from asdl import pybase

option_t = int  # type alias for integer

class option_i(object):
  errexit = 1
  nounset = 2
  hashall = 3
  pipefail = 4
  noexec = 5
  xtrace = 6
  verbose = 7
  noglob = 8
  noclobber = 9
  posix = 10
  vi = 11
  emacs = 12
  interactive = 13
  failglob = 14
  eval_unsafe_arith = 15
  parse_dynamic_arith = 16
  nullglob = 17
  inherit_errexit = 18
  strict_argv = 19
  strict_arith = 20
  strict_array = 21
  strict_control_flow = 22
  strict_echo = 23
  strict_errexit = 24
  strict_eval_builtin = 25
  strict_nameref = 26
  strict_word_eval = 27
  strict_backslash = 28
  strict_glob = 29
  simple_word_eval = 30
  dashglob = 31
  more_errexit = 32
  simple_test_builtin = 33
  parse_at = 34
  parse_brace = 35
  parse_index_expr = 36
  parse_paren = 37
  parse_rawc = 38
  parse_ignored = 39
  parse_set = 40
  parse_equals = 41
  expand_aliases = 42
  extglob = 43
  lastpipe = 44
  progcomp = 45
  histappend = 46
  hostcomplete = 47
  cmdhist = 48
  assoc_expand_once = 49
  autocd = 50
  cdable_vars = 51
  cdspell = 52
  checkhash = 53
  checkjobs = 54
  checkwinsize = 55
  complete_fullquote = 56
  direxpand = 57
  dirspell = 58
  dotglob = 59
  execfail = 60
  extdebug = 61
  extquote = 62
  force_fignore = 63
  globasciiranges = 64
  globstar = 65
  gnu_errfmt = 66
  histreedit = 67
  histverify = 68
  huponexit = 69
  interactive_comments = 70
  lithist = 71
  localvar_inherit = 72
  localvar_unset = 73
  login_shell = 74
  mailwarn = 75
  no_empty_cmd_completion = 76
  nocaseglob = 77
  nocasematch = 78
  progcomp_alias = 79
  promptvars = 80
  restricted_shell = 81
  shift_verbose = 82
  sourcepath = 83
  xpg_echo = 84
  ARRAY_SIZE = 85

_option_str = {
  1: 'option.errexit',
  2: 'option.nounset',
  3: 'option.hashall',
  4: 'option.pipefail',
  5: 'option.noexec',
  6: 'option.xtrace',
  7: 'option.verbose',
  8: 'option.noglob',
  9: 'option.noclobber',
  10: 'option.posix',
  11: 'option.vi',
  12: 'option.emacs',
  13: 'option.interactive',
  14: 'option.failglob',
  15: 'option.eval_unsafe_arith',
  16: 'option.parse_dynamic_arith',
  17: 'option.nullglob',
  18: 'option.inherit_errexit',
  19: 'option.strict_argv',
  20: 'option.strict_arith',
  21: 'option.strict_array',
  22: 'option.strict_control_flow',
  23: 'option.strict_echo',
  24: 'option.strict_errexit',
  25: 'option.strict_eval_builtin',
  26: 'option.strict_nameref',
  27: 'option.strict_word_eval',
  28: 'option.strict_backslash',
  29: 'option.strict_glob',
  30: 'option.simple_word_eval',
  31: 'option.dashglob',
  32: 'option.more_errexit',
  33: 'option.simple_test_builtin',
  34: 'option.parse_at',
  35: 'option.parse_brace',
  36: 'option.parse_index_expr',
  37: 'option.parse_paren',
  38: 'option.parse_rawc',
  39: 'option.parse_ignored',
  40: 'option.parse_set',
  41: 'option.parse_equals',
  42: 'option.expand_aliases',
  43: 'option.extglob',
  44: 'option.lastpipe',
  45: 'option.progcomp',
  46: 'option.histappend',
  47: 'option.hostcomplete',
  48: 'option.cmdhist',
  49: 'option.assoc_expand_once',
  50: 'option.autocd',
  51: 'option.cdable_vars',
  52: 'option.cdspell',
  53: 'option.checkhash',
  54: 'option.checkjobs',
  55: 'option.checkwinsize',
  56: 'option.complete_fullquote',
  57: 'option.direxpand',
  58: 'option.dirspell',
  59: 'option.dotglob',
  60: 'option.execfail',
  61: 'option.extdebug',
  62: 'option.extquote',
  63: 'option.force_fignore',
  64: 'option.globasciiranges',
  65: 'option.globstar',
  66: 'option.gnu_errfmt',
  67: 'option.histreedit',
  68: 'option.histverify',
  69: 'option.huponexit',
  70: 'option.interactive_comments',
  71: 'option.lithist',
  72: 'option.localvar_inherit',
  73: 'option.localvar_unset',
  74: 'option.login_shell',
  75: 'option.mailwarn',
  76: 'option.no_empty_cmd_completion',
  77: 'option.nocaseglob',
  78: 'option.nocasematch',
  79: 'option.progcomp_alias',
  80: 'option.promptvars',
  81: 'option.restricted_shell',
  82: 'option.shift_verbose',
  83: 'option.sourcepath',
  84: 'option.xpg_echo',
}

def option_str(val):
  # type: (option_t) -> str
  return _option_str[val]

builtin_t = int  # type alias for integer

class builtin_i(object):
  colon = 1
  dot = 2
  exec_ = 3
  eval = 4
  set = 5
  shift = 6
  times = 7
  trap = 8
  unset = 9
  builtin = 10
  readonly = 11
  local = 12
  declare = 13
  typeset = 14
  export_ = 15
  test = 16
  bracket = 17
  true_ = 18
  false_ = 19
  read = 20
  echo = 21
  printf = 22
  cd = 23
  pushd = 24
  popd = 25
  dirs = 26
  pwd = 27
  source = 28
  umask = 29
  wait = 30
  jobs = 31
  fg = 32
  bg = 33
  shopt = 34
  complete = 35
  compgen = 36
  compopt = 37
  compadjust = 38
  getopts = 39
  command = 40
  type = 41
  hash = 42
  help = 43
  history = 44
  alias = 45
  unalias = 46
  bind = 47
  push = 48
  append = 49
  write = 50
  getline = 51
  json = 52
  repr = 53
  use = 54
  opts = 55
  cat = 56
  ARRAY_SIZE = 57

_builtin_str = {
  1: 'builtin.colon',
  2: 'builtin.dot',
  3: 'builtin.exec_',
  4: 'builtin.eval',
  5: 'builtin.set',
  6: 'builtin.shift',
  7: 'builtin.times',
  8: 'builtin.trap',
  9: 'builtin.unset',
  10: 'builtin.builtin',
  11: 'builtin.readonly',
  12: 'builtin.local',
  13: 'builtin.declare',
  14: 'builtin.typeset',
  15: 'builtin.export_',
  16: 'builtin.test',
  17: 'builtin.bracket',
  18: 'builtin.true_',
  19: 'builtin.false_',
  20: 'builtin.read',
  21: 'builtin.echo',
  22: 'builtin.printf',
  23: 'builtin.cd',
  24: 'builtin.pushd',
  25: 'builtin.popd',
  26: 'builtin.dirs',
  27: 'builtin.pwd',
  28: 'builtin.source',
  29: 'builtin.umask',
  30: 'builtin.wait',
  31: 'builtin.jobs',
  32: 'builtin.fg',
  33: 'builtin.bg',
  34: 'builtin.shopt',
  35: 'builtin.complete',
  36: 'builtin.compgen',
  37: 'builtin.compopt',
  38: 'builtin.compadjust',
  39: 'builtin.getopts',
  40: 'builtin.command',
  41: 'builtin.type',
  42: 'builtin.hash',
  43: 'builtin.help',
  44: 'builtin.history',
  45: 'builtin.alias',
  46: 'builtin.unalias',
  47: 'builtin.bind',
  48: 'builtin.push',
  49: 'builtin.append',
  50: 'builtin.write',
  51: 'builtin.getline',
  52: 'builtin.json',
  53: 'builtin.repr',
  54: 'builtin.use',
  55: 'builtin.opts',
  56: 'builtin.cat',
}

def builtin_str(val):
  # type: (builtin_t) -> str
  return _builtin_str[val]

