/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 22
#define PATCHLEVEL 02
#define DATE "2019-12-04"

#endif /* _h_patchlevel */
