#!/usr/local/bin/fish

cppcheck --enable=all --std=posix --quiet ./src/
