.. _cmd-true:

true - return a successful result
=================================

Synopsis
--------

::

    true

Description
-----------

``true`` sets the exit status to 0.

See Also
--------

- :ref:`false <cmd-false>` command
- :ref:`$status <variables-status>` variable
