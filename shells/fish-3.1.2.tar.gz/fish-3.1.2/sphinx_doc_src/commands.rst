.. _commands:

Commands
============

fish ships with the following commands:

.. toctree::
   :glob:
   :maxdepth: 1
   
   cmds/*
