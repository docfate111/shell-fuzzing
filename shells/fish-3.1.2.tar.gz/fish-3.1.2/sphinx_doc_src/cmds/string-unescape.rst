string-unescape - expand escape sequences
=========================================

.. include:: string-escape.rst
   :start-line: 2
