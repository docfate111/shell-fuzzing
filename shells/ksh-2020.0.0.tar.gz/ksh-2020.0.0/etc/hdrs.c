// This is a trivial program used by the `lint` script to find out where the
// compiler thinks the system headers live.
#include <stdlib.h>
int main() { return 0; }
