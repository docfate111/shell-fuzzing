---
name: Bug report
about: Template for bug reports
---

**Description of problem:**


**Ksh version:**


**How reproducible:**


**Steps to reproduce:**
1.
2.
3.

**Actual results:**


**Expected results:**


**Additional info:**
