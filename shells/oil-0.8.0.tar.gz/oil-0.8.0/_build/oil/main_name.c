char* MAIN_NAME = "bin.oil";
#if OVM_DEBUG
  char* OVM_BUNDLE_FILENAME = "oil.ovm-dbg";
#else
  char* OVM_BUNDLE_FILENAME = "oil.ovm";
#endif
